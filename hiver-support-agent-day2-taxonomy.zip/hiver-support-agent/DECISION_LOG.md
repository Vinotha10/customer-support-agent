# Decision Log

Non-obvious calls made and why. Growing through the week — Day 1 entries below.

1. **Brand = AppleSupport**, not a smaller/quieter brand. Needed enough
   volume per discovered intent to retrieve grounded exemplars later, and
   wanted a support style with recognizable resolution patterns rather than
   highly bespoke/booking-specific replies (ruled out airlines for this).

2. **Pair unit is the brand reply, not the customer message.** A customer
   often tweets 2-3 times before a reply lands; anchoring on customer
   messages would create duplicate/ambiguous "which reply resolves this"
   cases. Anchoring on brand tweets makes the grounding corpus unambiguous:
   one brand reply = one exemplar of "how this brand resolved X."

3. **Strict parent validation, not best-effort.** A pair is only kept if
   `in_response_to_tweet_id` resolves to an actual row *and* that row is
   `inbound == True`. Two silent failure modes this catches: (a) dangling
   ids from the dataset's known missing-tweet gaps, (b) brand-to-brand
   cross-posts that would otherwise get miscounted as customer exchanges.
   Both are counted and printed, not swallowed.

4. **Follow-up text is a heuristic signal, not a resolution label.** Used
   later only as a soft feature (e.g. de-prioritizing exemplars whose
   follow-up looks like a re-complaint), never as ground truth for "this
   reply worked." Ground truth resolution requires the golden set.

5. **Intent taxonomy discovered from data, then manually named** — ran
   TF-IDF + KMeans over customer messages, swept k in {6,8,10,12}, picked
   by silhouette, and will read the actual sample sentences per cluster
   before deciding on ~6-9 named intents. Chose not to hand-guess a
   taxonomy from intuition, and chose not to skip the manual naming step
   and use unlabeled clusters directly — a support agent needs interpretable
   categories a human reviewer can audit.

6. **TF-IDF, not sentence embeddings, for the default clustering path.**
   Embeddings (e.g. MiniLM) would likely give tighter clusters, but
   introduce a HuggingFace model-download dependency. Given the "reproduce
   in under 15 minutes" constraint and no guarantee of network access at
   review time, TF-IDF is the default; embeddings are left as a documented
   swap-in for anyone with the model already cached.

7. **Raw text is kept unmodified at ingestion time**; no @mention stripping,
   no lowercasing, no redaction happens in `data_prep.py`. Cleaning is
   deferred to each downstream consumer (classifier prompt, RAG exemplar
   formatting) so no information is destroyed before we know what each
   stage actually needs.

8. **Thread reconstruction is unit-tested against a hand-built fixture with
   a known-correct answer**, not just eyeballed on the real dataset. Chose
   this over only manual spot-checking because the failure modes here
   (off-by-one hops, wrong inbound direction) are easy to introduce and
   easy to miss by eye on real noisy data, and they'd silently corrupt
   every downstream stage (classifier training, RAG grounding, golden set).

9. **Intent taxonomy locked into `outputs/clusters/intent_taxonomy_mapping.csv`**,
   a human-edited, plain-text mapping from `cluster_id` → intent name, with a
   `notes` column explaining every merge/exclusion decision inline.
   `src/intent_taxonomy.py` loads this CSV rather than hardcoding the mapping
   in Python — renaming or merging an intent later means editing one CSV row,
   not hunting through code. 8 intents kept; 2 clusters explicitly excluded
   from training as non-intents (see #10, #11).

10. **Clusters 6 and 8 excluded as "not an intent."** Both are customer
    follow-ups/acknowledgments ("thanks, fixed", "Yes it is.") answering a
    prior brand message, not new incoming complaints. Including them as a
    9th/10th "intent" would have meant training the classifier to predict
    a label that isn't actually an initial customer request — instead
    they're flagged as a likely `data_prep.py` pairing artifact worth
    verifying by hand (candidate failure-mode writeup for the report).

11. **Cluster 5 kept as an explicit, named catch-all (`general_software_complaint`)
    rather than force-split.** ~47% of the 3000-message clustering sample
    landed here, with mixed sub-topics and multiple languages present. A
    manual skim didn't reveal a clean further split. Named honestly as a
    catch-all instead of manufacturing false specificity — documented as
    a limitation in the report rather than hidden.

12. **`keyboard_autocorrect_bug` kept as its own narrow intent** rather than
    folded into `software_bug_after_update`, even though it's a small
    cluster (54 messages). Reasoning: it's one specific, recognizable known
    bug with a canned fix, which calls for a different reply strategy
    (point to the known fix) than a generic post-update bug report (which
    calls for "we're investigating" + escalation). Intent granularity here
    is driven by "does this need a different reply/escalation policy," not
    by cluster size alone.

