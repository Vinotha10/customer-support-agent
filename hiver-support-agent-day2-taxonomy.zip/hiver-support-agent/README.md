# Hiver SDE Intern Take-Home — AI Support Agent (AppleSupport)

Status: **Day 1 of 6** — data pipeline, EDA, intent-taxonomy discovery.
Classifier, RAG reply drafting, escalation logic, and eval harness land on
Days 3–5 (see decision log / report for the full plan).

## Setup (< 2 minutes)

```bash
git clone <this-repo>
cd hiver-support-agent
python3 -m venv .venv && source .venv/bin/activate
pip install -r requirements.txt
```

## Get the data (~5 minutes, manual — Kaggle requires auth)

1. Download `twcs.csv` from Kaggle:
   https://www.kaggle.com/datasets/thoughtvector/customer-support-on-twitter
   (Kaggle CLI: `kaggle datasets download -d thoughtvector/customer-support-on-twitter`)
2. Unzip and place the file at `data/raw/twcs.csv`.

This step can't be automated in the pipeline itself since it needs your
Kaggle credentials — everything after this is one command each.

## Reproduce Day 1 results (< 15 minutes total on a laptop CPU)

```bash
cd src
python3 data_prep.py       # ~1-3 min: filters to AppleSupport, reconstructs
                            # (customer_msg -> brand_reply) pairs
python3 eda.py              # ~10s: volume, response time, multi-turn %, top tokens
python3 cluster_intents.py  # ~1-2 min: TF-IDF+KMeans clusters for taxonomy discovery
```

Outputs:
- `data/processed/applesupport_pairs.parquet` — the reconstructed pairs, used
  by every later stage (classifier training, RAG exemplar retrieval, golden
  set sampling).
- `outputs/eda_summary.txt`, `outputs/figures/response_time_hist.png`
- `outputs/clusters/cluster_samples.csv` — 5-6 sample messages per discovered
  cluster with top TF-IDF terms. **You read this file and manually name each
  cluster as an intent** (e.g. cluster 3's top terms "screen, cracked" →
  `hardware_damage`). That mapping goes in `src/intent_taxonomy.py` (Day 2)
  and is a deliberate manual step, not automated — see decision log.

## Run tests

```bash
python3 -m pytest tests/ -v
```

These test the thread-reconstruction logic (`data_prep.py`) against a small
hand-built fixture (`tests/fixtures/mini_twcs.csv`) with a known-correct
answer, covering: dangling parent ids, brand-to-brand replies (should be
dropped, not miscounted as a pair), prior-context lookup, follow-up
capture, and response-time computation. This is meant to catch the subtle
threading bugs (off-by-one hops, wrong inbound direction) before they
silently corrupt every downstream stage.

## Why AppleSupport

High message volume and a support style with recognizable, repeatable
resolution patterns (troubleshooting steps, "DM us," refund language) —
this matters because reply drafting is grounded in *how this brand has
historically resolved similar issues*, which needs a large-enough set of
resolved-looking exchanges per intent to retrieve from.

## Repo layout

```
src/
  config.py            # brand + path + sampling knobs, single source of truth
  data_prep.py         # raw twcs.csv -> reconstructed (customer, brand_reply) pairs
  eda.py               # volume / response-time / multi-turn / token stats
  cluster_intents.py   # TF-IDF+KMeans clustering for intent taxonomy discovery
tests/
  test_data_prep.py    # unit tests for thread reconstruction, run on a known fixture
  fixtures/mini_twcs.csv
data/
  raw/                 # put twcs.csv here (gitignored)
  processed/           # generated pair data (gitignored)
outputs/
  figures/, clusters/, eda_summary.txt   # generated (gitignored)
```

## Key decisions from Day 1 (full list continues in decision log)

- **Pair unit = brand tweet, not customer tweet.** A customer can send
  several tweets before one reply; we anchor on the brand's reply since
  that's what reply-drafting is grounded on.
- **A pair is only valid if the parent tweet is actually inbound (customer).**
  Brand-to-brand replies and dangling `in_response_to_tweet_id` values are
  dropped and counted, not silently ignored — `data_prep.py` prints drop
  reasons so the loss is visible.
- **Follow-up text is captured as a weak resolution *heuristic*, not ground
  truth.** A customer saying "thanks!" doesn't prove the issue was actually
  fixed; a customer going quiet doesn't prove it wasn't. This gets flagged
  again in the report's "what's misleading about my headline number"
  section.
- **Intent taxonomy is discovered via clustering, then manually named** —
  not hand-guessed up front and not left as raw unlabeled clusters. TF-IDF
  is the default clustering input (not embeddings) specifically so the
  whole pipeline stays dependency-light and reproducible offline in under
  15 minutes; a sentence-transformer swap is noted in
  `cluster_intents.py` for anyone who wants marginally better cluster
  cohesion and already has the model cached.
